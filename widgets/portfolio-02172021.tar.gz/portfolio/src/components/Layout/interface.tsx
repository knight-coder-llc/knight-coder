export interface LayoutProps {
    title?: string 
}