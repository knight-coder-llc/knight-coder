export interface ChatBotProps {
    pid: string,
    aid: string
}