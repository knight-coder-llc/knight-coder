export interface NavigationProps {
    links: Array<string>
}

export interface FooterProps {
    links?: Array<string>
}