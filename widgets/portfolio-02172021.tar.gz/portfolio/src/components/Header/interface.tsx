export interface HeaderProps {
    tite?: string
}
