export interface CarouselProps {
    
}