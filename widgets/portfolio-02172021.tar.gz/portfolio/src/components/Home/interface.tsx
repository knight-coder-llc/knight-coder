export interface HomePageProps {
    imgSrc: string,
    title?: string
}